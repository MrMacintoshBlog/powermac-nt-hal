# Frozen HALIM2 source and recovered baseline

Prepared November 5, 2026 for continuation of the physical ANS 700 work.

The included source is the `hal-iomapfix2` snapshot used for the recovered
NPFS checkpoint. `HALIM2.DLL` is the verified deployment artifact, exactly
`D600` bytes, FNV `085AE99B`, SHA-256
`d2fb635ae4760ffe394dafa80e41fe6e06e60b3b7b2725316160fb16a5d89c8f`.
It contains the DMA, cache, GPIO, SCSIRING2 and CRASH1 changes documented
in the repository handoff. The current root-level repository source is an
older project snapshot. Use this frozen source for the recovered baseline.

From this directory on the tested Mac toolchain, build the HAL target with

```sh
make CLANG=/opt/homebrew/opt/llvm/bin/clang LLD=/opt/homebrew/bin/ld.lld build/hal.dll
shasum -a 256 HALIM2.DLL build/hal.dll
```

The documented toolchain is LLVM clang/lld 23.1.1. Compiler changes can alter
the binary. Confirm the exact identity and the `D600` allocation limit before
using a rebuilt image on hardware. Targeting `build/hal.dll` builds the HAL
without changing the ADB driver. `SOURCE-MANIFEST.json` is at archive root.

The fixed HDD deployment allocation belongs to the documented ANS install.
Consult the hardware handoff before any disk write. The current machine
already contains this baseline and the next NPFS check is read-only.
