/* CRASH1: supported bugcheck callback; no kernel instruction patches.
 * Context recovery is deliberately restricted to fingerprinted NT PPC paths.
 */
#include "hal.h"

volatile ULONG HalpSweepState[5] __attribute__((aligned(32)));
#include "crash_fingerprint.h"
extern BOOLEAN MmIsAddressValid(PVOID);
extern BOOLEAN KeRegisterBugCheckCallback(PVOID, PVOID, PVOID, ULONG, PUCHAR);
extern VOID HalpCrashCallbackThunk(VOID);
static FUNC_DESC callbackDesc = {(PVOID)HalpCrashCallbackThunk, 0};
static ULONG record[8], scratch, kernelBase, busy;
static ULONG history[8][7], count;

static BOOLEAN readable(ULONG a, ULONG n)
{
    if (a < 0x80000000u || a >= 0xf0000000u || !n || n > 4096 || a > 0xf0000000u-n) return FALSE;
    for (ULONG p=a;;) {
        if (!MmIsAddressValid((PVOID)p)) return FALSE;
        ULONG next=(p&~4095u)+4096;
        if (next>a+n-1) break;
        p=next;
    }
    return TRUE;
}
static ULONG word(ULONG a) { return *(volatile ULONG *)a; }
static ULONG hash(ULONG a, ULONG n)
{
    ULONG h=2166136261u;
    for (ULONG i=0;i<n;i++) h=(h^*(volatile UCHAR *)(a+i))*16777619u;
    return h;
}
VOID HalpCrashRemember(PMDL mdl, ULONG mapped)
{
    ULONG *r=history[count++ & 7];
    r[0]=(ULONG)mdl; r[1]=(USHORT)mdl->MdlFlags;
    r[2]=(ULONG)mdl->StartVa; r[3]=mapped;
    r[4]=mdl->ByteOffset; r[5]=mdl->ByteCount; r[6]=(USHORT)mdl->Size>=sizeof(MDL)+4 ? ((PULONG)(mdl+1))[0] : 0;
}
static VOID modules(ULONG pc)
{
    ULONG head=kernelBase+0x7b490, e=head, matched=0;
    for (ULONG i=0;i<128;i++) {
        if (!readable(e,8)) break;
        ULONG previous=e;
        e=word(e);
        if (e==head) { HalpPrint("CRASH1 MODULE-END matched %d\n",matched); return; }
        if ((e&3) || !readable(e,52) || word(e+4)!=previous) break;
        ULONG base=word(e+24), size=word(e+32);
        if (pc>=base && pc-base<size) {
            ULONG n=*(volatile USHORT *)(e+44)/2, name=word(e+48);
            char text[49]; if(n>48)n=48;
            if (!n || (name&1) || !readable(name,n*2)) n=0;
            for (ULONG j=0;j<n;j++) text[j]=(char)*(volatile USHORT *)(name+j*2);
            text[n]=0;
            HalpPrint("CRASH1 OWNER %s base %x size %x rva %x\n",text,base,size,pc-base);
            matched=1;
        }
    }
    HalpPrint("CRASH1 MODULE-LIST-INCOMPLETE matched %d\n",matched);
}
VOID HalpCrashCallbackLog(ULONG dispatchSp, ULONG originLr, ULONG callbackLr, ULONG dispatchLr)
{
    if (busy++) return;
    HalpPrint("\nCRASH1 BEGIN origin %x cb %x dispatcher %x\n",originLr,callbackLr,dispatchLr);
    ULONG data=kernelBase+0x7a570;
    if (!readable(data,20)) return;
    ULONG code=word(data), pc=word(data+8);
    HalpPrint("CRASH1 STOP %x %x %x %x %x\n",code,word(data+4),pc,word(data+12),word(data+16));
    HalpPrint("SWEEP1 STATE entered %d completed %d HID0 %x DBAT0 %x %x\n",
              HalpSweepState[0], HalpSweepState[1], HalpSweepState[2], HalpSweepState[3], HalpSweepState[4]);
    ULONG ctx=0, ex=0;
    if (code==0x1e && callbackLr==kernelBase+0x304c4 && dispatchLr==kernelBase+0x30044 &&
        !(dispatchSp&15) && readable(dispatchSp,4)) {
        ULONG bugSp=word(dispatchSp);
        if (bugSp==dispatchSp+128 && readable(bugSp,4)) {
            ULONG callerSp=word(bugSp);
            if (callerSp==bugSp+736 && readable(callerSp-8,112)) {
                ULONG rva=originLr-kernelBase;
                if ((rva==0x3497c || rva==0x34c30) && word(callerSp-4)==callerSp) {
                    ex=word(callerSp-8); ctx=callerSp+104;
                } else if (rva==0x6901c) {
                    ULONG pair=word(callerSp+88);
                    if (!(pair&3) && readable(pair,8)) { ex=word(pair); ctx=word(pair+4); }
                }
            }
        }
    }
    if (!(ctx&3) && !(ex&3) && readable(ctx,432) && readable(ex,28) &&
        word(ctx+404)==pc && word(ex)==word(data+4) && word(ex+12)==pc &&
        (word(ctx+416)&5)==5) {
        HalpPrint("CRASH1 CONTEXT %x exception %x flags %x\n",ctx,ex,word(ctx+416));
        for (ULONG i=0;i<32;i+=4)
            HalpPrint("CRASH1 GPR %d %x %x %x %x\n",i,word(ctx+264+4*i),word(ctx+268+4*i),word(ctx+272+4*i),word(ctx+276+4*i));
        HalpPrint("CRASH1 CR %x XER %x MSR %x PC %x LR %x CTR %x\n",word(ctx+392),word(ctx+396),word(ctx+400),pc,word(ctx+408),word(ctx+412));
        ULONG sp=word(ctx+268), start=sp;
        for (ULONG i=0;i<8 && !(sp&15) && readable(sp,16);i++) {
            ULONG next=word(sp);
            HalpPrint("CRASH1 STACK %x %x %x %x %x\n",sp,next,word(sp+4),word(sp+8),word(sp+12));
            if(next<=sp || next-start>32768) break;
            sp=next;
        }
    } else HalpPrint("CRASH1 CONTEXT-UNAVAILABLE\n");
    if(code==0x1e) {
    modules(pc);
    ULONG a=pc&~3u;
    if (a>=16 && readable(a-16,48)) {
        for (ULONG i=0;i<12;i+=4)
            HalpPrint("CRASH1 CODE %x %x %x %x %x\n",a-16+4*i,word(a-16+4*i),word(a-12+4*i),word(a-8+4*i),word(a-4+4*i));
    } else HalpPrint("CRASH1 CODE-UNAVAILABLE\n");
    }
    ULONG first=count>8?count-8:0;
    for (ULONG i=first;i<count;i++) {
        ULONG *r=history[i&7];
        HalpPrint("CRASH1 IO %d mdl %x flags %x start %x map %x\n",i+1,r[0],r[1],r[2],r[3]);
        HalpPrint("CRASH1 IO-RANGE off %x count %x pfn0 %x\n",r[4],r[5],r[6]);
    }
    extern VOID HalpScsiRingDump(VOID);
    HalpScsiRingDump();
    HalpPrint("CRASH1 END\n");
}
VOID HalpInstallCrashTrace(PLOADER_PARAMETER_BLOCK loader)
{
    for (PLIST_ENTRY e=loader->LoadOrderListHead.Flink;e!=&loader->LoadOrderListHead;e=e->Flink) {
        PLDR_DATA_TABLE_ENTRY m=(PLDR_DATA_TABLE_ENTRY)e;
        if(m->BaseDllName.Length!=24)continue;
        const char *name="ntoskrnl.exe"; ULONG i;
        for(i=0;i<12;i++) { ULONG c=m->BaseDllName.Buffer[i]; if(c>='A' && c<='Z')c+=32; if(c!=(ULONG)name[i])break; }
        if(i==12) { kernelBase=(ULONG)m->DllBase; break; }
    }
    if (!kernelBase) goto fail;
    for (ULONG i=0;i<sizeof(fingerprints)/sizeof(fingerprints[0]);i++) {
        ULONG a=kernelBase+fingerprints[i][0], n=fingerprints[i][1];
        if (!readable(a,n) || hash(a,n)!=fingerprints[i][2]) goto fail;
    }
    if (word(kernelBase+0xa28)!=kernelBase+0x7b490) goto fail;
    if (!KeRegisterBugCheckCallback(record,&callbackDesc,&scratch,sizeof(scratch),(PUCHAR)"CRASH1")) goto fail;
    HalpPrint("CRASH1 INSTALLED kernel %x fingerprint 7/7\n",kernelBase);
    return;
fail:
    HalpPrint("CRASH1 NOT-INSTALLED fingerprint/registration\n");
}
