/* SPDX-License-Identifier: GPL-2.0-only
 * Diagnostic for the uploaded NT4 PPC SYMC810.SYS only.
 * Observe before forwarding; never change SRB data or completion status.
 */
#include "hal.h"
PVOID HalpTraceNotifyOriginal;
PVOID HalpTraceCompleteOriginal;
extern VOID HalpTraceNotifyThunk(VOID);
extern VOID HalpTraceCompleteThunk(VOID);
static FUNC_DESC notifyDesc = { (PVOID)HalpTraceNotifyThunk, 0 };
static FUNC_DESC completeDesc = { (PVOID)HalpTraceCompleteThunk, 0 };
/* Ring entries contain metadata only; never dereference a DMA data buffer.
 * IRQ-disabled publication prevents the other adapter from interleaving writes. */
static volatile ULONG ring[32][8], total;
static ULONG get32(volatile UCHAR *p)
{ return (ULONG)p[0]|((ULONG)p[1]<<8)|((ULONG)p[2]<<16)|((ULONG)p[3]<<24); }
static VOID record(ULONG kind,ULONG adapter,ULONG ids,ULONG status,ULONG lba,ULONG blocks,ULONG len)
{
    ULONG msr;
    __asm__ volatile("mfmsr %0":"=r"(msr));
    ULONG off=msr&~0x8000u;
    __asm__ volatile("mtmsr %0\n\tisync"::"r"(off):"memory");
    ULONG n=total;
    volatile ULONG *r=ring[n&31];
    r[0]=n+1;r[1]=kind;r[2]=adapter;r[3]=ids;r[4]=status;r[5]=lba;r[6]=blocks;r[7]=len;
    __asm__ volatile("sync":::"memory");total=n+1;
    __asm__ volatile("mtmsr %0\n\tisync"::"r"(msr):"memory");
}
VOID HalpTraceNotifyLog(ULONG type,ULONG adapter,volatile UCHAR *srb,ULONG caller)
{
    if(type || !srb || ((ULONG)srb&3) || ((ULONG)srb[0]|((ULONG)srb[1]<<8))<64) return;
    ULONG op=srb[10]?srb[48]:255,lba=0,blocks=0;
    if(srb[10]>=10 && (op==0x28 || op==0x2a)) {
        lba=((ULONG)srb[50]<<24)|((ULONG)srb[51]<<16)|((ULONG)srb[52]<<8)|srb[53];
        blocks=((ULONG)srb[55]<<8)|srb[56];
    }
    record(0,adapter,((ULONG)srb[5]<<24)|((ULONG)srb[6]<<16)|((ULONG)srb[7]<<8)|srb[10],
        ((ULONG)srb[2]<<24)|((ULONG)srb[3]<<16)|((ULONG)srb[4]<<8)|op,lba,blocks,get32(srb+16));
}
/* caller is the direct API caller; resetlr is raw r28 at that boundary.
 * Interpret resetlr only when caller matches the fingerprinted reset routine. */
VOID HalpTraceCompleteLog(ULONG adapter,ULONG path,ULONG target,ULONG lun,ULONG status,ULONG caller,ULONG resetlr)
{ record(1,adapter,(path<<24)|(target<<16)|(lun<<8),status,caller,resetlr,0); }
VOID HalpScsiRingDump(VOID)
{
    ULONG end=total,start=end>32?end-32:0;
    HalpPrint("SCSIRING2 count %d\n",end);
    for(ULONG i=start;i<end;i++) {
        volatile ULONG *r=ring[i&31];
        HalpPrint("SCSIRING2 %d kind %x adapter %x ids %x status %x\n",r[0],r[1],r[2],r[3],r[4]);
        HalpPrint("SCSIRING2 detail %x %x %x\n",r[5],r[6],r[7]);
    }
}
static BOOLEAN named(PLDR_DATA_TABLE_ENTRY m, const char *wanted)
{
    ULONG n = m->BaseDllName.Length / 2, i;
    for (i=0; i<n; ++i) {
        ULONG c = m->BaseDllName.Buffer[i];
        if (!wanted[i]) return FALSE;
        if (c >= 'A' && c <= 'Z') c += 'a'-'A';
        if (c != (ULONG)(UCHAR)wanted[i]) return FALSE;
    }
    return wanted[i] == 0;
}
VOID HalpInstallScsiTrace(PLOADER_PARAMETER_BLOCK loader)
{
    PLDR_DATA_TABLE_ENTRY driver = NULL, port = NULL;
    for (PLIST_ENTRY e=loader->LoadOrderListHead.Flink; e!=&loader->LoadOrderListHead; e=e->Flink) {
        PLDR_DATA_TABLE_ENTRY m=(PLDR_DATA_TABLE_ENTRY)e;
        if (named(m,"symc810.sys")) driver=m;
        if (named(m,"scsiport.sys")) port=m;
    }
    if (!driver || !port || HalpTraceNotifyOriginal) {
        HalpPrint("HAL: SCSIRING2 NOT INSTALLED: module missing or already hooked\n");
        return;
    }
    volatile UCHAR *b=(volatile UCHAR *)driver->DllBase;
    /* Exact known PE layout: e_lfanew 80, PPC, timestamp, entry, image size, checksum. */
    if (get32(b+0x3c)!=0x80 || get32(b+0x80)!=0x4550 ||
        b[0x84]!=0xf0 || b[0x85]!=1 || get32(b+0x88)!=0x31ed22e3 ||
        get32(b+0xa8)!=0x3fc || get32(b+0xd0)!=0x79e0 || get32(b+0xd8)!=0x7d8c) {
        HalpPrint("HAL: SCSIRING2 NOT INSTALLED: driver fingerprint mismatch\n");
        return;
    }
    PVOID *ni=(PVOID *)(b+0x2fc), *ci=(PVOID *)(b+0x300);
    ULONG low=(ULONG)port->DllBase, high=low+port->SizeOfImage;
    ULONG nd=(ULONG)*ni, cd=(ULONG)*ci;
    if ((nd&3) || (cd&3) || nd<low || nd>high-8 || cd<low || cd>high-8) {
        HalpPrint("HAL: SCSIRING2 NOT INSTALLED: unexpected import descriptors\n");
        return;
    }
    ULONG ne=get32((volatile UCHAR *)nd), ce=get32((volatile UCHAR *)cd);
    if (ne<low || ne>=high || ce<low || ce>=high) {
        HalpPrint("HAL: SCSIRING2 NOT INSTALLED: unexpected import entrypoints\n");
        return;
    }
    /* GPIOCMP1: exact CD9 instruction changes, applied before miniport entry.
     * The CD and its file checksum remain untouched. Require stock instructions.
     */
    if (get32(b+0x5dc)!=0x7f8802a6u || get32(b+0x628)!=0x4e800021u || get32(b+0x1634)!=0x38800008u || get32(b+0x16d4)!=0x73c400feu) {
        HalpPrint("HAL: GPIOCMP1 NOT APPLIED: instruction mismatch\n");
        return;
    }
    b[0x1634]=0x0f;
    b[0x16d4]=0xff;
    __asm__ volatile("sync" ::: "memory");
    HalSweepDcacheRange((PVOID)(b+0x1634), 4);
    HalSweepDcacheRange((PVOID)(b+0x16d4), 4);
    HalSweepIcacheRange((PVOID)(b+0x1634), 4);
    HalSweepIcacheRange((PVOID)(b+0x16d4), 4);
    __asm__ volatile("sync\n\tisync" ::: "memory");
    HalpPrint("HAL: GPIOCMP1 applied: stock SYMC810 GPIO 08->0F, FE->FF; CACHEMAP1 retained\n");
    HalpTraceNotifyOriginal=*ni;
    HalpTraceCompleteOriginal=*ci;
    __asm__ volatile("sync" ::: "memory");
    *ni=&notifyDesc;
    *ci=&completeDesc;
    __asm__ volatile("sync\n\tisync" ::: "memory");
    HalpPrint("HAL: SCSIRING2 installed at symc810 %x; 32 metadata entries\n", (ULONG)b);
}
