/* SPDX-License-Identifier: GPL-2.0-only
 * Copyright (C) 2026 powermac-nt-hal contributors
 *
 * UPSTREAM: Wack0/entii-for-workcubes, halartx/source/ (GPL-2.0, commit c9b041da).
 *   Which adapter routines may be stubs comes from reading `hwsup.c`.
 *   Rewritten from reading: no lines were copied, and the code here was written fresh
 *   for Grand Central, Bandit and the ESCC.  See PROVENANCE.md.
 *
 * dma.c — adapter objects and common buffers.  PCI bus masters on the Network Server address
 * memory directly (Bandit is coherent with the 604), so map registers are identity and a
 * common buffer is contiguous non-paged memory. */
#include "hal.h"

typedef struct _ADAPTER_OBJECT { CSHORT Type, Size; ULONG MapRegistersPerChannel; BOOLEAN Master; } ADAPTER_OBJECT;
static ADAPTER_OBJECT HalpMasterAdapter = { 0, sizeof(ADAPTER_OBJECT), 64, TRUE };

PADAPTER_OBJECT HalGetAdapter(PDEVICE_DESCRIPTION Desc, PULONG NumberOfMapRegisters)
{
    HalpPrint("HAL: GetAdapter type %d bus %d master %d sg %d maxlen %x\n", Desc->InterfaceType, Desc->BusNumber, Desc->Master, Desc->ScatterGather, Desc->MaximumLength);
    if (Desc->Version > DEVICE_DESCRIPTION_VERSION1) return NULL;
    if (Desc->InterfaceType != PCIBus && Desc->InterfaceType != Internal) return NULL;
    if (!Desc->Master) return NULL;             /* no slave DMA controller on this machine */
    ULONG regs = (Desc->MaximumLength + 4095) / 4096 + 1;
    if (regs > 64) regs = 64;
    *NumberOfMapRegisters = regs;
    return &HalpMasterAdapter;
}

/* A bus master on this machine needs no translation, so there is nothing to hand out and nothing
 * that can be contended for: the "map register base" is a token the driver only passes back to
 * IoMapTransfer and IoFreeMapRegisters.  Every request is therefore granted immediately, in the
 * caller's context, which is what the kernel's IoAllocateAdapterChannel wrapper expects when it
 * returns STATUS_SUCCESS without having queued anything. */
static ULONG HalpMapRegisters[1];

NTSTATUS HalAllocateAdapterChannel(PADAPTER_OBJECT Adapter, PWAIT_CONTEXT_BLOCK Wcb, ULONG NumberOfMapRegisters, PDRIVER_CONTROL ExecutionRoutine)
{
    if (NumberOfMapRegisters > Adapter->MapRegistersPerChannel) return STATUS_INSUFFICIENT_RESOURCES;
    Wcb->NumberOfMapRegisters = NumberOfMapRegisters;
    HalpCallDesc4(ExecutionRoutine, (ULONG)Wcb->DeviceObject, (ULONG)Wcb->CurrentIrp,
                  (ULONG)HalpMapRegisters, (ULONG)Wcb->DeviceContext);
    /* KeepObject / DeallocateObject / DeallocateObjectKeepRegisters all mean the same here */
    return STATUS_SUCCESS;
}

PVOID HalAllocateCommonBuffer(PADAPTER_OBJECT Adapter, ULONG Length, PPHYSICAL_ADDRESS LogicalAddress, BOOLEAN CacheEnabled)
{
    UNREFERENCED_PARAMETER(Adapter); UNREFERENCED_PARAMETER(CacheEnabled);
    PVOID va = MmAllocateContiguousMemory(Length, 0xFFFFFFFFull);
    if (!va) return NULL;
    MmGetPhysicalAddress(LogicalAddress, va);
    return va;
}

BOOLEAN HalFlushCommonBuffer(PADAPTER_OBJECT Adapter, ULONG Length, PHYSICAL_ADDRESS LogicalAddress, PVOID VirtualAddress)
{
    UNREFERENCED_PARAMETER(Adapter); UNREFERENCED_PARAMETER(Length); UNREFERENCED_PARAMETER(LogicalAddress); UNREFERENCED_PARAMETER(VirtualAddress);
    return TRUE;
}

VOID HalFreeCommonBuffer(PADAPTER_OBJECT Adapter, ULONG Length, PHYSICAL_ADDRESS LogicalAddress, PVOID VirtualAddress, BOOLEAN CacheEnabled)
{
    UNREFERENCED_PARAMETER(Adapter); UNREFERENCED_PARAMETER(Length); UNREFERENCED_PARAMETER(LogicalAddress); UNREFERENCED_PARAMETER(CacheEnabled);
    MmFreeContiguousMemory(VirtualAddress);
}

PVOID HalAllocateCrashDumpRegisters(PADAPTER_OBJECT Adapter, PULONG NumberOfMapRegisters)
{
    UNREFERENCED_PARAMETER(Adapter); UNREFERENCED_PARAMETER(NumberOfMapRegisters);
    return NULL;
}

/* PHYSICAL_ADDRESS IoMapTransfer(...) — eight-byte result through the hidden pointer in r3. */
PPHYSICAL_ADDRESS IoMapTransfer(PPHYSICAL_ADDRESS Result, PADAPTER_OBJECT Adapter, PMDL Mdl, PVOID MapRegisterBase,
                                PVOID CurrentVa, PULONG Length, BOOLEAN WriteToDevice)
{
    UNREFERENCED_PARAMETER(Adapter); UNREFERENCED_PARAMETER(MapRegisterBase); UNREFERENCED_PARAMETER(WriteToDevice);
    /* one physically contiguous run at a time, taken from the MDL's page array */
    PULONG pages = (PULONG)(Mdl + 1);
    ULONG requested = *Length;
    ULONG byteOffset = Mdl->ByteOffset, byteCount = Mdl->ByteCount;

    /* A true zero-length request needs no PFN lookup and makes no progress by definition. */
    if (!requested) {
        *Length = 0;
        *Result = (PHYSICAL_ADDRESS)0;
        return Result;
    }

    /* Never turn malformed MDL geometry into a PFN-array index. */
    if (byteOffset >= 4096 || !byteCount || byteCount > 0xFFFFFFFFu - byteOffset)
        KeBugCheckEx(0xE2, 0x494D0001, (ULONG)Mdl, byteOffset, byteCount);

    ULONG limit = byteOffset + byteCount;
    ULONG current = (ULONG)CurrentVa;
    ULONG offset = 0xFFFFFFFFu;
    ULONG start = (ULONG)Mdl->StartVa;

    /* MapTransfer's normal index is MmGetMdlVirtualAddress(Mdl) == StartVa + ByteOffset. */
    if (current >= start) {
        ULONG rel = current - start;
        if (rel >= byteOffset && rel < limit)
            offset = rel;
    }

    /* Defensive mapped-VA fallback: trust MappedSystemVa only when NT marks it valid. */
    if (offset == 0xFFFFFFFFu &&
        (Mdl->MdlFlags & 0x0001) &&       /* MDL_MAPPED_TO_SYSTEM_VA */
        Mdl->MappedSystemVa) {
        ULONG mapped = (ULONG)Mdl->MappedSystemVa;
        if (current >= mapped) {
            ULONG progress = current - mapped;
            if (progress < byteCount)
                offset = byteOffset + progress;
        }
    }

    /* The NT4 SCSIPORT scatter/gather caller has no safe zero-progress error return. */
    if (offset == 0xFFFFFFFFu)
        KeBugCheckEx(0xE2, 0x494D0002, (ULONG)Mdl, current, requested);

    ULONG idx = offset >> 12, inpage = offset & 0xFFF;
    ULONG total = limit - offset;
    ULONG npages = (ULONG)(((ULONGLONG)limit + 4095u) >> 12);
    ULONG maxRun = requested < total ? requested : total;
    ULONG run = 4096 - inpage;
    if (run > maxRun) run = maxRun;

    while (run < maxRun) {
        ULONG next = (ULONG)(((ULONGLONG)run + inpage) >> 12);
        if (idx + next >= npages) break;
        if (pages[idx + next] != pages[idx] + next) break;
        ULONG remaining = maxRun - run;
        if (remaining <= 4096) {
            run = maxRun;
            break;
        }
        run += 4096;
    }
    *Length = run;
    *Result = (PHYSICAL_ADDRESS)((pages[idx] << 12) + inpage);
    return Result;
}

BOOLEAN IoFlushAdapterBuffers(PADAPTER_OBJECT Adapter, PMDL Mdl, PVOID MapRegisterBase, PVOID CurrentVa, ULONG Length, BOOLEAN WriteToDevice)
{
    UNREFERENCED_PARAMETER(Adapter); UNREFERENCED_PARAMETER(Mdl); UNREFERENCED_PARAMETER(MapRegisterBase);
    UNREFERENCED_PARAMETER(CurrentVa); UNREFERENCED_PARAMETER(Length); UNREFERENCED_PARAMETER(WriteToDevice);
    return TRUE;
}

VOID IoFreeMapRegisters(PADAPTER_OBJECT Adapter, PVOID MapRegisterBase, ULONG NumberOfMapRegisters)
{
    UNREFERENCED_PARAMETER(Adapter); UNREFERENCED_PARAMETER(MapRegisterBase); UNREFERENCED_PARAMETER(NumberOfMapRegisters);
}

VOID IoFreeAdapterChannel(PADAPTER_OBJECT Adapter)
{
    UNREFERENCED_PARAMETER(Adapter);
}

ULONG HalReadDmaCounter(PADAPTER_OBJECT Adapter)
{
    UNREFERENCED_PARAMETER(Adapter);
    return 0;
}

ULONG HalGetDmaAlignmentRequirement(VOID)
{
    return 1;
}

/* Flush pages an I/O read brought in, so the instruction cache never sees stale code. */
VOID HalFlushIoBuffers(PMDL Mdl, BOOLEAN ReadOperation, BOOLEAN DmaOperation)
{
    /* ANS-CACHEMAP1: a PFN does not imply a mapped 0x80000000 alias. */
    UNREFERENCED_PARAMETER(DmaOperation);
    if (!ReadOperation || !(Mdl->MdlFlags & MDL_IO_PAGE_READ)) return;
    if (!Mdl->ByteCount) return;
    ULONG offset = Mdl->ByteOffset, count = Mdl->ByteCount;
    ULONG flags = (USHORT)Mdl->MdlFlags;
    PVOID mapped;
    BOOLEAN ownMapping = FALSE;
    /* Intentional diagnostic stop (MANUALLY_INITIATED_CRASH), never silently
     * skip required cache maintenance or flush an invented address. */
    if (offset >= 4096 || count > 0xFFFFFFFFu - offset - 4095)
        KeBugCheckEx(0xE2, 0x434D0001, (ULONG)Mdl, offset, count);
    if (flags & 0x0001) {             /* MDL_MAPPED_TO_SYSTEM_VA */
        mapped = Mdl->MappedSystemVa;
    } else if (flags & 0x0004) {      /* MDL_SOURCE_IS_NONPAGED_POOL */
        mapped = Mdl->StartVa;
    } else {
        if (PCR->CurrentIrql > DISPATCH_LEVEL)
            KeBugCheckEx(0xE2, 0x434D0002, (ULONG)Mdl, flags, PCR->CurrentIrql);
        mapped = MmMapLockedPages(Mdl, KernelMode);
        ownMapping = TRUE;
    }
    if ((ULONG)mapped < 0x80000000u)
        KeBugCheckEx(0xE2, 0x434D0003, (ULONG)Mdl, flags, (ULONG)mapped);
    extern VOID HalpCrashRemember(PMDL, ULONG);
    HalpCrashRemember(Mdl, (ULONG)mapped);
    ULONG first = (ULONG)mapped & ~4095u;
    ULONG span = (offset + count + 4095) & ~4095u;
    if (first > 0xFFFFFFFFu - (span - 1))
        KeBugCheckEx(0xE2, 0x434D0004, (ULONG)Mdl, first, span);
    for (ULONG done = 0; done < span; done += 4096) {
        HalSweepDcacheRange((PVOID)(first + done), 4096);

        HalSweepIcacheRange((PVOID)(first + done), 4096);
    }

    if (ownMapping) {
        MmUnmapLockedPages(mapped, Mdl);
    }

}

