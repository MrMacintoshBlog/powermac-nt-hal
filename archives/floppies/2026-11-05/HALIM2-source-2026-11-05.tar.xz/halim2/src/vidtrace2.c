/* VIDTRACE3: preserve VIDTRACE2 and observe CIRRUS.SYS HwFindAdapter.
 * Diagnostic only: no original return values or hardware register values are changed.
 */
#include "hal.h"
PVOID HalpVidInitializeOriginal;
PVOID HalpVidFindOriginal;
PVOID HalpVidBaseOriginal;
PVOID HalpVidVerifyOriginal;
PVOID HalpVidReadPortOriginal;
PVOID HalpVidWritePortOriginal;
extern VOID HalpVidInitializeThunk(VOID);
extern VOID HalpVidFindThunk(VOID);
extern VOID HalpVidBaseThunk(VOID);
extern VOID HalpVidVerifyThunk(VOID);
extern VOID HalpVidReadPortThunk(VOID);
extern VOID HalpVidWritePortThunk(VOID);
static FUNC_DESC initDesc = { (PVOID)HalpVidInitializeThunk, 0 };
static FUNC_DESC findDesc = { (PVOID)HalpVidFindThunk, 0 };
static FUNC_DESC baseDesc = { (PVOID)HalpVidBaseThunk, 0 };
static FUNC_DESC verifyDesc = { (PVOID)HalpVidVerifyThunk, 0 };
static FUNC_DESC readPortDesc = { (PVOID)HalpVidReadPortThunk, 0 };
static FUNC_DESC writePortDesc = { (PVOID)HalpVidWritePortThunk, 0 };
static ULONG HalpVidDriverLow;
static ULONG HalpVidDriverHigh;
static PVOID *HalpVidFindSlot;
static ULONG HalpVidFindActive;
static ULONG get32v(volatile UCHAR *p)
{
    return (ULONG)p[0] | ((ULONG)p[1] << 8) | ((ULONG)p[2] << 16) | ((ULONG)p[3] << 24);
}
static BOOLEAN namedv(PLDR_DATA_TABLE_ENTRY m, const char *wanted)
{
    ULONG n = m->BaseDllName.Length / 2, i;
    for (i = 0; i < n; ++i) {
        ULONG ch = m->BaseDllName.Buffer[i];
        if (!wanted[i]) return FALSE;
        if (ch >= 'A' && ch <= 'Z') ch += 'a' - 'A';
        if (ch != (ULONG)(UCHAR)wanted[i]) return FALSE;
    }
    return wanted[i] == 0;
}
VOID HalpVidInitializeLog(ULONG status, ULONG interfaceType)
{
    static ULONG count;
    if (count >= 8) return;
    count++;
    HalpPrint("HAL: VIDTRACE3 VideoPortInitialize type %x -> %x\n",
              interfaceType, status);
}
VOID HalpVidFindEntryLog(PVOID hwdev, PVOID hwctx, PVOID argument,
                         PVOID config, PUCHAR again)
{
    static ULONG count;
    ULONG len = 0, bus = 0, type = 0, againValue = 0xff;
    volatile UCHAR *p = (volatile UCHAR *)config;
    if (count >= 16) return;
    count++;
    if (p) {
        len = get32v(p);
        if (len >= 12) {
            bus = get32v(p + 4);
            type = get32v(p + 8);
        }
    }
    if (again) againValue = *again;
    HalpPrint("HAL: VIDTRACE3 HwFindAdapter ENTER dev %x ctx %x arg %x cfg %x len %x bus %x type %x again %x\n",
              (ULONG)hwdev, (ULONG)hwctx, (ULONG)argument, (ULONG)config,
              len, bus, type, againValue);
}
VOID HalpVidFindReturnLog(ULONG status, PVOID hwdev, PVOID hwctx,
                          PVOID argument, PVOID config, PUCHAR again)
{
    static ULONG count;
    ULONG len = 0, bus = 0, type = 0, againValue = 0xff;
    volatile UCHAR *p = (volatile UCHAR *)config;
    if (count >= 16) return;
    count++;
    if (p) {
        len = get32v(p);
        if (len >= 12) {
            bus = get32v(p + 4);
            type = get32v(p + 8);
        }
    }
    if (again) againValue = *again;
    HalpPrint("HAL: VIDTRACE3 HwFindAdapter RETURN %x dev %x cfg %x len %x bus %x type %x again %x\n",
              status, (ULONG)hwdev, (ULONG)config, len, bus, type, againValue);
}
VOID HalpVidPrepareFind(PVOID initData, ULONG interfaceType)
{
    volatile UCHAR *p = (volatile UCHAR *)initData;
    ULONG size, desc, entry;
    PVOID *slot;
    if (!p) {
        HalpPrint("HAL: VIDTRACE3 HwFindAdapter NOT ARMED: null init data\n");
        return;
    }
    size = get32v(p);
    if (size < 12) {
        HalpPrint("HAL: VIDTRACE3 HwFindAdapter NOT ARMED: init size %x\n", size);
        return;
    }
    if (HalpVidFindActive) {
        HalpPrint("HAL: VIDTRACE3 HwFindAdapter NOT ARMED: already active\n");
        return;
    }
    slot = (PVOID *)(p + 8);
    desc = (ULONG)*slot;
    if ((desc & 3) || desc < HalpVidDriverLow || desc > HalpVidDriverHigh - 8) {
        HalpPrint("HAL: VIDTRACE3 HwFindAdapter NOT ARMED: descriptor %x out of CIRRUS range\n", desc);
        return;
    }
    entry = get32v((volatile UCHAR *)desc);
    if (entry < HalpVidDriverLow || entry >= HalpVidDriverHigh) {
        HalpPrint("HAL: VIDTRACE3 HwFindAdapter NOT ARMED: entry %x out of CIRRUS range\n", entry);
        return;
    }
    HalpVidFindOriginal = *slot;
    HalpVidFindSlot = slot;
    HalpVidFindActive = 1;
    __asm__ volatile("sync" ::: "memory");
    *slot = &findDesc;
    __asm__ volatile("sync\n\tisync" ::: "memory");
    HalpPrint("HAL: VIDTRACE3 armed HwFindAdapter type %x init %x desc %x entry %x\n",
              interfaceType, (ULONG)initData, desc, entry);
}
VOID HalpVidRestoreFind(PVOID initData)
{
    if (!HalpVidFindActive) return;
    if (HalpVidFindSlot && *HalpVidFindSlot == &findDesc) {
        __asm__ volatile("sync" ::: "memory");
        *HalpVidFindSlot = HalpVidFindOriginal;
        __asm__ volatile("sync\n\tisync" ::: "memory");
    } else {
        HalpPrint("HAL: VIDTRACE3 warning: HwFindAdapter slot changed before restore\n");
    }
    HalpVidFindSlot = NULL;
    HalpVidFindActive = 0;
}

static ULONG HalpVidSeqIndex;
ULONG HalpVidPortReadFilter(ULONG port, ULONG value)
{
    ULONG v=value & 0xff;
    if ((port & 0xfff)==0x3c5 && HalpVidSeqIndex==0x15 && (v & 0x0f)==0) {
        ULONG fixed=(v & ~0x0f) | 0x02;
        HalpPrint("HAL: VIDFIX1 SR15 %x -> %x\n",v,fixed);
        return fixed;
    }
    return value;
}

VOID HalpVidPortReadLog(ULONG port, ULONG value)
{
    static ULONG n;
    if (n++ < 96) HalpPrint("HAL: VIDTRACE5 PortRead %x -> %x\n",port,value & 0xff);
}
VOID HalpVidPortWriteLog(ULONG port, ULONG value)
{
    static ULONG n;
    if ((port & 0xfff)==0x3c4) HalpVidSeqIndex=value & 0xff;
    if (n++ < 96) HalpPrint("HAL: VIDTRACE5 PortWrite %x <- %x\n",port,value & 0xff);
}

VOID HalpVidImportLog(ULONG which, ULONG result, PULONG a)
{
    static ULONG count;
    if (count++ >= 32) return;
    if (which == 0)
        HalpPrint("HAL: VIDTRACE4 GetDeviceBase -> %x r3 %x r4 %x r5 %x r6 %x r7 %x r8 %x\n",
                  result,a[0],a[1],a[2],a[3],a[4],a[5]);
    else
        HalpPrint("HAL: VIDTRACE4 VerifyAccessRanges -> %x r3 %x count %x ranges %x\n",
                  result,a[0],a[1],a[2]);
}

VOID HalpInstallVideoTrace(PLOADER_PARAMETER_BLOCK loader)
{
    PLDR_DATA_TABLE_ENTRY driver = NULL, port = NULL;
    for (PLIST_ENTRY e = loader->LoadOrderListHead.Flink;
         e != &loader->LoadOrderListHead; e = e->Flink) {
        PLDR_DATA_TABLE_ENTRY m = (PLDR_DATA_TABLE_ENTRY)e;
        if (namedv(m, "cirrus.sys")) driver = m;
        if (namedv(m, "videoprt.sys")) port = m;
    }
    if (!driver || !port || HalpVidInitializeOriginal) {
        HalpPrint("HAL: VIDTRACE3 NOT INSTALLED: module missing or already hooked\n");
        return;
    }
    volatile UCHAR *b = (volatile UCHAR *)driver->DllBase;
    if (get32v(b + 0x3c) != 0x80 ||
        get32v(b + 0x80) != 0x4550 ||
        b[0x84] != 0xf0 || b[0x85] != 1 ||
        get32v(b + 0x88) != 0x31ef1395 ||
        get32v(b + 0xa8) != 0x4a8 ||
        get32v(b + 0xd0) != 0xede0 ||
        get32v(b + 0xd8) != 0x16a76) {
        HalpPrint("HAL: VIDTRACE3 NOT INSTALLED: CIRRUS fingerprint mismatch\n");
        return;
    }
    PVOID *vi = (PVOID *)(b + 0x370);
    ULONG low = (ULONG)port->DllBase;
    ULONG high = low + port->SizeOfImage;
    ULONG desc = (ULONG)*vi;
    if ((desc & 3) || desc < low || desc > high - 8) {
        HalpPrint("HAL: VIDTRACE3 NOT INSTALLED: unexpected VideoPortInitialize descriptor %x\n",
                  desc);
        return;
    }
    ULONG entry = get32v((volatile UCHAR *)desc);
    if (entry < low || entry >= high) {
        HalpPrint("HAL: VIDTRACE3 NOT INSTALLED: unexpected VideoPortInitialize entry %x\n",
                  entry);
        return;
    }
    HalpVidDriverLow = (ULONG)b;
    HalpVidDriverHigh = HalpVidDriverLow + driver->SizeOfImage;

    PVOID *vb = (PVOID *)(b + 0x344);
    PVOID *vv = (PVOID *)(b + 0x348);
    PVOID *vpw = (PVOID *)(b + 0x360);
    PVOID *vpr = (PVOID *)(b + 0x368);
    HalpVidBaseOriginal = *vb;
    HalpVidVerifyOriginal = *vv;
    HalpVidWritePortOriginal = *vpw;
    HalpVidReadPortOriginal = *vpr;
    HalpVidInitializeOriginal = *vi;

    __asm__ volatile("sync" ::: "memory");
    *vb = &baseDesc;
    *vv = &verifyDesc;
    *vpw = &writePortDesc;
    *vpr = &readPortDesc;
    __asm__ volatile("sync" ::: "memory");
    *vi = &initDesc;
    __asm__ volatile("sync\n\tisync" ::: "memory");
    HalpPrint("HAL: VIDTRACE3 installed at cirrus %x IAT %x original %x\n",
              (ULONG)b, (ULONG)vi, (ULONG)HalpVidInitializeOriginal);
}
