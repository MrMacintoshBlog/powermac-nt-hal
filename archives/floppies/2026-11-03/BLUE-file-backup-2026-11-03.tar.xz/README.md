# BLUE floppy file-backup archive

Prepared 2026-11-03 at the owner's request for sharing the ANS investigation.
This archive contains saved file payloads under `files/`, their SHA-256 hashes,
and a provenance manifest. It is a file archive, not a raw floppy image or
a fresh capture of the physical disk. It contains no FAT allocation map,
boot-sector capture or complete unused/deleted sector data. Mac `._` and
`.fseventsd` metadata is excluded. Payload bytes are preserved unchanged.

BLUE is assembled from the verified 2026-10-02 pre-HALV1 file backup
plus the preserved, verified HALV1.DLL subsequently copied to BLUE. This is
the documented file set, not a November physical-sector capture. Historical
HAL candidates are included as archival files; inclusion does not select
them for deployment. HALV1 is the last verified installed HAL; HALRS1 is the
frozen diagnostic baseline; HALIM2 is the separately preserved recovery HAL.

BOOTDISK.OF reads its veneer using fixed raw floppy LBAs (starting at 0x15D),
so copying these files to a newly formatted floppy does not establish a
working boot disk. Preserve/use a known-good boot disk or a separately
verified complete image for reproduction. Do not write this archive as an image.
The archived PPC/SETUPLDR was identified as Alpha (machine 0x184); it is not
the PPC installed-system loader. The active boot route loads the PPC
OSLOADER.EXE from the ANS hard disk.

Inspect `MANIFEST.json` for the source of each file. `SHA256SUMS.txt` covers
the files below `files/`. These are testing backups, not a new software release.
The repository's project source licence does not describe every third-party
payload's origin; the manifest identifies what was backed up.
