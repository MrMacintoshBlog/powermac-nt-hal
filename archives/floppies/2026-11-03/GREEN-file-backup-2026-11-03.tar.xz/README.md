# GREEN floppy file-backup archive

Prepared 2026-11-03 at the owner's request for sharing the ANS investigation.
This archive contains saved file payloads under `files/`, their SHA-256 hashes,
and a provenance manifest. It is a file archive, not a raw floppy image or
a fresh capture of the physical disk. It contains no FAT allocation map,
boot-sector capture or complete unused/deleted sector data. Mac `._` and
`.fseventsd` metadata is excluded. Payload bytes are preserved unchanged.

GREEN holds only the original and diagnostic 512-byte OSLOADER sector
references. Both saved byte copies matched complete ANS firmware-load dumps
on 2026-10-02 and their media fingerprints were rechecked during 2026-11-03
testing. OSLOLD.SCT FNV is 52610671; OSLNEW.SCT FNV is 5FE5BDE9.

The files differ only at offsets 0x1CC..0x1CF: 3C238038 -> 0000E463. They
refer to the mapped target sector of this specific installed loader. LBA
0x1229 is specific to the documented ANS allocation and is not a universal
patch location. GREEN is recovery data media, not a boot disk. The archive
can supply its two file payloads, but does not reproduce the physical disk's
FAT layout or establish another machine's restore target.

Inspect `MANIFEST.json` for the source of each file. `SHA256SUMS.txt` covers
the files below `files/`. These are testing backups, not a new software release.
The repository's project source licence does not describe every third-party
payload's origin; the manifest identifies what was backed up.
